package sms_project.sms_project.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import sms_project.sms_project.Entity.Student;



public interface StudentRepository extends JpaRepository<Student, Long> {

}
