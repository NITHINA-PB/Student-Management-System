package sms_project.sms_project;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import sms_project.sms_project.repository.StudentRepository;

@SpringBootApplication
public class SmsProjectApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(SmsProjectApplication.class, args);
	}
	@Autowired
	private StudentRepository studentRepository;
	
	@Override
	public void run(String... args)throws Exception{
		
	}

}
